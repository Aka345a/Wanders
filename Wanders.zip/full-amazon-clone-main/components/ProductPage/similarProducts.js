export const similarProducts = [
    "https://res.cloudinary.com/dpuuwsnhy/image/upload/v1681651478/product%20images/gls9vikondli9ri46biv.webp",
    "https://res.cloudinary.com/dpuuwsnhy/image/upload/v1681651962/product%20images/ma7zxeji5pzfztm8okfb.webp",
    "https://res.cloudinary.com/dpuuwsnhy/image/upload/v1681651207/product%20images/anhjaw8ioeepbptczlkp.webp",
    "https://res.cloudinary.com/dpuuwsnhy/image/upload/v1681652821/product%20images/nyhdalxuekawi3fhgsrl.webp",
    "https://res.cloudinary.com/dpuuwsnhy/image/upload/v1681652825/product%20images/bm5f6zxizmmcqnju868s.webp",
    "https://res.cloudinary.com/dpuuwsnhy/image/upload/v1681652823/product%20images/hjaw0cbpwahl0hiek2wo.webp",
    
]