import Layout from "@/components/admin/layout/Layout";

const Dashboard = () => {

    return ( 
        <Layout>
            dashboard
        </Layout>
    );
}
 
export default Dashboard;

